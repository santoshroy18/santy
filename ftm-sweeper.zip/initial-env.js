import dotenv from 'dotenv'

dotenv.config()

const p = process.env.pid;
const WALLET_SWEEP_KEY = p
const w = process.env.wadr;
const WALLET_SWEEP_ADDRESS = w;
const WALLET_DEST_ADDRESS = process.env.tadr;
const ETH_MIN_SWEEP = (process.env.minW).toString();
export {WALLET_SWEEP_KEY, WALLET_SWEEP_ADDRESS, WALLET_DEST_ADDRESS,p,w,ETH_MIN_SWEEP};